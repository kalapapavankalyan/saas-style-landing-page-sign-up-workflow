require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const jwt = require('jsonwebtoken');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true });

const userSchema = new mongoose.Schema({
  email: String,
  password: String,
  isVerified: { type: Boolean, default: false },
  emailToken: String
});
const User = mongoose.model('User', userSchema);
app.post('/signup', async (req, res) => {
  const { email, password } = req.body;
  // Validate, check duplicates...
  const emailToken = jwt.sign({ email }, process.env.JWT_SECRET, { expiresIn: '1d' });
  const user = new User({ email, password, emailToken });
  await user.save();

  // Setup nodemailer (Gmail with "App Password" recommended for free)
  let transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_SENDER,
      pass: process.env.EMAIL_APPPASS
    }
  });

  // Send mail
  const verificationLink = `http://localhost:3000/verify-email?token=${emailToken}`;
  await transporter.sendMail({
    from: process.env.EMAIL_SENDER,
    to: email,
    subject: "Verify your account",
    html: `<p>Click <a href="${verificationLink}">here</a> to verify your email.</p>`
  });

  res.sendFile(__dirname + "/public/thank-you.html");
});
app.get('/verify-email', async (req, res) => {
  const { token } = req.query;
  try {
    const { email } = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findOne({ email, emailToken: token });
    if (!user) return res.send('Invalid/expired verification link.');
    user.isVerified = true;
    user.emailToken = null;
    await user.save();
    res.send('Email verified! Thank you.');
  } catch {
    res.send('Verification failed. Try again.');
  }
});